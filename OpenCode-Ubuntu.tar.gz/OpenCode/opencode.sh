#!/bin/bash
#GitHub:OpenPkg7
#OpenCode Script
#Download in Repository "Systems"
#v0.1
echo "Log: installing fastfetch or neofetch with apt"
sudo apt install neofetch
sudo apt install fastfetch
echo "Log: neofetch/fastfetch installed"
echo "Log: install btop with htop with apt"
sudo apt install htop
sudo apt install btop
echo "Log: btop installed"
echo "Log: install cmatrix with apt"
sudo apt install cmatrix
echo "Log: cmatrix installed"
echo "Finish Thank you for use my script!!" 
